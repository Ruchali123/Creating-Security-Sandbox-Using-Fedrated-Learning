# server.py - Federated Learning Server
import flwr as fl
import numpy as np
import signal
import sys
import torch
from federated_training import LogisticRegression
from flask import Flask, request, jsonify



# Define strategy for aggregating client models
def weighted_average(metrics):
    accuracies = [num_examples * accuracy for num_examples, accuracy in metrics]
    examples = [num_examples for num_examples, _ in metrics]
    return {"accuracy": sum(accuracies) / sum(examples)}

# Define Flower server strategy
strategy = fl.server.strategy.FedAvg(evaluate_metrics_aggregation_fn=weighted_average)

# Correct config using ServerConfig
from flwr.server import ServerConfig
config = ServerConfig(num_rounds=3)

# Graceful shutdown handler
def signal_handler(signal, frame):
    print("\nShutting down server gracefully...")
    sys.exit(0)

# Catch signals for graceful termination
signal.signal(signal.SIGINT, signal_handler)  # Ctrl + C
signal.signal(signal.SIGTERM, signal_handler)  # Docker/Process Termination

# Start Flower server
if __name__ == "__main__":
    try:
        fl.server.start_server(
            server_address="0.0.0.0:8080",  # ✅ Correctly set to 0.0.0.0
            config=config,
            strategy=strategy
        )
    except Exception as e:
        print(f"Error occurred while running the server: {e}")


# Load the trained model
model_path = "backend/global_model.pth"
input_dim = 10  # Update this if your input size changes
model = LogisticRegression(input_dim)
model.load_state_dict(torch.load(model_path))
model.eval()

print("✅ Model loaded successfully!")

app = Flask(__name__)

@app.route("/predict", methods=["POST"])
def predict():
    try:
        data = request.json["data"]
        data_array = np.array(data).reshape(1, -1)  # Reshape for single sample
        input_tensor = torch.tensor(data_array, dtype=torch.float32)

        with torch.no_grad():
            output = model(input_tensor).squeeze().item()
            prediction = 1 if output >= 0.5 else 0

        return jsonify({"prediction": prediction})

    except Exception as e:
        return jsonify({"error": str(e)})
    
if __name__ == "__main__":
    try:
        # Start Flower Server in a separate thread
        from threading import Thread

        def start_fl_server():
            fl.server.start_server(
                server_address="0.0.0.0:8080",
                config=config,
                strategy=strategy
            )

        # Start Flask server
        Thread(target=start_fl_server).start()

        # Start Flask API on port 5000
        app.run(host="0.0.0.0", port=5000, debug=True)
    except Exception as e:
        print(f"Error occurred: {e}")


