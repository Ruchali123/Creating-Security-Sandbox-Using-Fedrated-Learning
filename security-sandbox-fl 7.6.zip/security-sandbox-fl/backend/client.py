# client.py - Federated Learning Client
import flwr as fl
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import os

# Load and preprocess dataset based on type
def load_data(dataset_type="pattern"):
    file_paths = {
        "pattern": "uploads/pattern_data.txt",
        "network": "uploads/network_traffic.txt",
        "anomaly": "uploads/anomaly_data.txt"
    }

    # Check if dataset type is valid
    if dataset_type not in file_paths:
        print(f"Error: Unsupported dataset type '{dataset_type}'!")
        exit()

    file_path = file_paths[dataset_type]

    # Check if the file exists
    if not os.path.exists(file_path):
        print(f"Error: File '{file_path}' not found!")
        exit()

    try:
        # Try reading the file
        data = pd.read_csv(file_path, header=None)

        # Check if the file is empty
        if data.empty:
            print(f"Error: File '{file_path}' is empty or contains no valid data.")
            exit()

        return data
    except pd.errors.EmptyDataError:
        print("Error: No columns to parse from file.")
        exit()
    except Exception as e:
        print(f"Error reading the file: {e}")
        exit()


# Load data and split into training and testing
def prepare_data(dataset_type="pattern"):
    data = load_data(dataset_type)

    # Separate features and labels
    X = data.iloc[:, :-1].values
    y = data.iloc[:, -1].values

    # Split data into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    return X_train, X_test, y_train, y_test


# Prepare data for chosen dataset type
dataset_type = os.getenv("DATASET_TYPE", "pattern")  # Default is pattern recognition
X_train, X_test, y_train, y_test = prepare_data(dataset_type)

# Initialize the model
model = LogisticRegression()


# Define Flower client
class FLClient(fl.client.NumPyClient):
    def get_parameters(self, config):
        return [val for _, val in model.get_params().items()]

    def set_parameters(self, parameters):
        param_dict = dict(zip(model.get_params().keys(), parameters))
        model.set_params(**param_dict)

    def fit(self, parameters, config):
        self.set_parameters(parameters)
        model.fit(X_train, y_train)
        return self.get_parameters(config), len(X_train), {}

    def evaluate(self, parameters, config):
        self.set_parameters(parameters)
        y_pred = model.predict(X_test)
        accuracy = accuracy_score(y_test, y_pred)
        return float(accuracy), len(X_test), {"accuracy": float(accuracy)}


# Start Flower client
if __name__ == "__main__":
    fl.client.start_numpy_client(server_address="server:8080", client=FLClient())





