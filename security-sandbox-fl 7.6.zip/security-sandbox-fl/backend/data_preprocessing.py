# import pandas as pd

# # Define file paths
# file_paths = {
#     "anomaly_data": "backend/uploads/anomaly_data.txt",
#     "network_traffic": "backend/uploads/network_traffic.txt",
#     "pattern_data": "backend/uploads/pattern_data.txt"
# }

# # Load data into pandas dataframes
# dataframes = {}
# for name, path in file_paths.items():
#     dataframes[name] = pd.read_csv(path, delimiter=',', header=0)  # Change delimiter if necessary

# # Check data samples
# for name, df in dataframes.items():
#     print(f"Data Sample - {name}:")
#     print(df.head())

# # Handle missing values by filling with mean (or use dropna if preferred)
# for name, df in dataframes.items():
#     dataframes[name] = df.fillna(df.mean())  # Fill missing values with mean
#     dataframes[name] = df.drop_duplicates()  # Remove duplicate entries

# # Check if data is clean
# for name, df in dataframes.items():
#     print(f"Cleaned Data - {name}:")
#     print(df.head())



import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
import numpy as np
import joblib
import os

# Define file paths
file_paths = {
    "anomaly_data": "uploads/anomaly_data.txt",
    "network_traffic": "uploads/network_traffic.txt",
    "pattern_data": "uploads/pattern_data.txt"
}


# Define file paths (fixed paths)
file_paths = {
    "anomaly_data": "uploads/anomaly_data.txt",
    "network_traffic": "uploads/network_traffic.txt",
    "pattern_data": "uploads/pattern_data.txt"
}

# Load data into pandas dataframes
dataframes = {}

for name, path in file_paths.items():
    file_path = path  # Corrected to direct path without base_path
    if os.path.exists(file_path):
        # Read CSV files with header as the first row
        dataframes[name] = pd.read_csv(file_path, delimiter=',', header=0)

    else:
        print(f"⚠️ File not found: {file_path}")

# Check data samples
for name, df in dataframes.items():
    print(f"Data Sample - {name}:")
    print(df.head())

# Drop non-numeric columns for numerical operations before any preprocessing
non_numeric_cols = ['timestamp', 'source_ip', 'destination_ip', 'protocol']
for name, df in dataframes.items():
    if name == 'network_traffic':
        dataframes[name] = df.drop(columns=non_numeric_cols, errors='ignore')

# Handle missing values and duplicates
for name, df in dataframes.items():
    dataframes[name] = df.fillna(df.mean())  # Fill missing values with mean
    dataframes[name] = df.drop_duplicates()  # Remove duplicate entries

print("Data cleaning completed...")


# Normalize/Scale the data
scaler = StandardScaler()

# Apply normalization to each dataset
for name, df in dataframes.items():
    if not df.empty:
        dataframes[name] = pd.DataFrame(scaler.fit_transform(df), columns=df.columns)

# Check normalized data
for name, df in dataframes.items():
    print(f"Normalized Data - {name}:")
    print(df.head())
    print("data normalized succesfully!!")

# Split data into training and test sets
train_test_data = {}

for name, df in dataframes.items():
    # Define X and y (change target column name if needed)
    X = df.iloc[:, :-1]  # All columns except the last as features
    y = df.iloc[:, -1]   # Last column as target

    # Split data into training and test sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    train_test_data[name] = {
        "X_train": X_train,
        "X_test": X_test,
        "y_train": y_train,
        "y_test": y_test
    }

print("Data successfully split into training and testing sets.")

# Prepare data for federated clients
federated_data = {}

for name, data in train_test_data.items():
    federated_data[name] = {
        "X_train": np.array(data["X_train"]),
        "X_test": np.array(data["X_test"]),
        "y_train": np.array(data["y_train"]),
        "y_test": np.array(data["y_test"])
    }

print("Data prepared for federated learning clients.")

# Ensure the 'uploads' directory exists
uploads_dir = os.path.join(os.path.dirname(__file__), "uploads")

if not os.path.exists(uploads_dir):
    os.makedirs(uploads_dir)  # Create the directory if it doesn't exist

# Save the federated data
federated_data_path = os.path.join(uploads_dir, "federated_data.pkl")
joblib.dump(federated_data, federated_data_path)

print(f"✅ Federated data saved successfully at {federated_data_path}")



# backend/database.py
import sqlite3

DB_PATH = "database.db"

def init_db():
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS analysis (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            file_name TEXT,
            file_size INTEGER,
            file_hash TEXT,
            anomaly_score REAL,
            traffic_score REAL,
            pattern_type TEXT
        )
        """)
        conn.commit()

def save_analysis(result):
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute("""
        INSERT INTO analysis (file_name, file_size, file_hash, anomaly_score, traffic_score, pattern_type)
        VALUES (?, ?, ?, ?, ?, ?)
        """, (
            result["file_name"],
            result["file_size"],
            result["file_hash"],
            result["anomaly_score"],
            result["traffic_score"],
            result["pattern_type"]
        ))
        conn.commit()

def get_all_analyses():
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM analysis")
        return cursor.fetchall()