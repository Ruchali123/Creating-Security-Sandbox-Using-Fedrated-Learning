import os
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
import numpy as np
import joblib
import time
import json
import sqlite3
from datetime import datetime
import hashlib
import random


# Define Logistic Regression Model
class LogisticRegression(nn.Module):
    def __init__(self, input_dim):
        super(LogisticRegression, self).__init__()
        self.linear = nn.Linear(input_dim, 1)

    def forward(self, x):
        return torch.sigmoid(self.linear(x))


# Set Up Multiple Clients
def create_clients(data, labels, num_clients=5):
    client_data = np.array_split(data, num_clients)
    client_labels = np.array_split(labels, num_clients)
    clients = []

    for i in range(num_clients):
        if len(client_data[i]) == 0 or len(client_labels[i]) == 0:
            print(f"⚠️ Skipping client {i+1} due to empty data.")
            continue

        dataset = TensorDataset(torch.tensor(client_data[i], dtype=torch.float32),
                                torch.tensor(client_labels[i], dtype=torch.float32))

        if len(dataset) > 0:
            clients.append(DataLoader(dataset, batch_size=32, shuffle=True))
        else:
            print(f"⚠️ No data available for client {i+1}, skipping...")

    print(f"✅ Created {len(clients)} clients successfully!")
    return clients


# FedAvg Aggregation
def aggregate_models(global_model, client_models, num_clients):
    global_state = global_model.state_dict()
    for key in global_state.keys():
        global_state[key] = torch.stack(
            [client_models[i].state_dict()[key].float() for i in range(num_clients)], 0
        ).mean(0)
    global_model.load_state_dict(global_state)


# Train and Evaluate
def train_model(client_data, global_model, num_clients=5, num_rounds=10, lr=0.01):
    criterion = nn.BCELoss()

    for round_num in range(num_rounds):
        client_models = []

        for client in client_data:
            if len(client) == 0:
                print("⚠️ Skipping empty client...")
                continue

            client_model = LogisticRegression(input_dim=client.dataset.tensors[0].shape[1])
            client_model.load_state_dict(global_model.state_dict())
            optimizer = optim.SGD(client_model.parameters(), lr=lr)

            for epoch in range(3):
                for data, target in client:
                    if data.numel() == 0 or target.numel() == 0:
                        continue

                    optimizer.zero_grad()
                    output = client_model(data).flatten()
                    loss = criterion(output, target.float())
                    loss.backward()
                    optimizer.step()

            client_models.append(client_model)

        if len(client_models) > 0:
            aggregate_models(global_model, client_models, len(client_models))
            print(f'✅ Round {round_num+1}/{num_rounds} complete.')
        else:
            print("⚠️ No models to aggregate, skipping aggregation...")


# Evaluate the Model
def evaluate_model(global_model, test_data, test_labels):
    test_dataset = TensorDataset(torch.tensor(test_data, dtype=torch.float32),
                                 torch.tensor(test_labels, dtype=torch.float32))
    test_loader = DataLoader(test_dataset, batch_size=32, shuffle=False)

    correct, total = 0, 0
    with torch.no_grad():
        for data, target in test_loader:
            output = global_model(data).squeeze()
            predicted = (output >= 0.5).float()
            correct += (predicted == target).sum().item()
            total += target.size(0)
    accuracy = correct / total
    print(f'✅ Test Accuracy: {accuracy * 100:.2f}%')


# Analyze a File Using the Trained Model
def analyze_file(file_path):
    with open(file_path, 'rb') as f:
        content = f.read()

    # Simulate extracting metadata & doing analysis
    file_size = os.path.getsize(file_path)
    file_name = os.path.basename(file_path)
    file_hash = hashlib.sha256(content).hexdigest()

    # Simulated analysis results
    anomaly_score = round(random.uniform(0, 1), 2)
    traffic_score = round(random.uniform(0, 1), 2)
    pattern_type = random.choice(["Suspicious", "Benign", "Malware"])

    result = {
        "file_name": file_name,
        "file_size": file_size,
        "file_hash": file_hash,
        "anomaly_score": anomaly_score,
        "traffic_score": traffic_score,
        "pattern_type": pattern_type
    }
    return result

    
        # if len(data.shape) == 1:
        #     data = data.reshape(1, -1)

        # if data.shape[1] != 2:
        #     print(f"❌ Error: Expected 2 input features but got {data.shape[1]}")
        #     return

        # data_tensor = torch.tensor(data, dtype=torch.float32)

        # with torch.no_grad():
        #     output = model(data_tensor).flatten()
        #     predictions = (output >= 0.5).float()

        # result_dict = {
        #     "predictions": predictions.numpy().tolist()
        # }

        # print("✅ File analyzed successfully. Predictions:")
        # print(result_dict["predictions"])

        # store_analysis_result(file_path, result_dict)
    # else:
    #     print(f"❌ File '{file_path}' not found.")


def store_analysis_result(filename, result_dict):
    conn = sqlite3.connect("app.db")
    cursor = conn.cursor()

    # Create table if it doesn't exist
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS files (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            filename TEXT,
            result TEXT
        )
    """)

    file_size = os.path.getsize(filename)
    upload_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(os.path.getmtime(filename)))

    result_dict.update({
        "filename": os.path.basename(filename),
        "size_kb": round(file_size / 1024, 2),
        "upload_time": upload_time
    })

    cursor.execute("INSERT INTO files (filename, result) VALUES (?, ?)", (
        os.path.basename(filename), json.dumps(result_dict)
    ))
    conn.commit()
    conn.close()


# Main Logic
if __name__ == "__main__":
    federated_data_path = os.path.join("uploads", "federated_data.pkl")

    if os.path.exists(federated_data_path):
        print("✅ Loading federated data...")
        federated_data = joblib.load(federated_data_path)

        X_train = federated_data["network_traffic"]["X_train"]
        y_train = federated_data["network_traffic"]["y_train"]
        X_test = federated_data["network_traffic"]["X_test"]
        y_test = federated_data["network_traffic"]["y_test"]

        y_train = (y_train > 0).astype(float)
        y_test = (y_test > 0).astype(float)

        print(f"Unique values in y_train: {np.unique(y_train)}")
        print(f"Unique values in y_test: {np.unique(y_test)}")
        print(f"Size of X_train: {X_train.shape}")
        print(f"Size of y_train: {y_train.shape}")
        print(f"Size of X_test: {X_test.shape}")
        print(f"Size of y_test: {y_test.shape}")

        unique, counts = np.unique(y_train, return_counts=True)
        print(f"Class distribution in y_train: {dict(zip(unique, counts))}")

        clients = create_clients(X_train, y_train, num_clients=5)
        global_model = LogisticRegression(input_dim=X_train.shape[1])

        print("🎯 Starting federated training...")
        train_model(clients, global_model, num_clients=len(clients), num_rounds=10)

        model_path = os.path.join("backend", "global_model.pth")
        torch.save(global_model.state_dict(), model_path)
        print(f"✅ Global model saved at {model_path}")

        print("🔎 Evaluating global model...")
        evaluate_model(global_model, X_test, y_test)

        print("🔎 Evaluating model on training data...")
        evaluate_model(global_model, X_train, y_train)

        file_path = os.path.join("uploads", "new_data.txt")
        print("🔍 Analyzing a new file...")
        analyze_file(file_path)

    else:
        print(f"❌ Federated data not found at '{federated_data_path}'")
