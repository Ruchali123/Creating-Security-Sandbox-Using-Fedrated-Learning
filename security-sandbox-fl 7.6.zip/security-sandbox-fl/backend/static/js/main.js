// ===========================
// ✅ Login Form Logic
// ===========================
document.addEventListener("DOMContentLoaded", function () {
    const loginForm = document.getElementById("loginForm");

    if (loginForm) {
        loginForm.addEventListener("submit", function (event) {
            event.preventDefault(); // Prevent default form submission

            const username = document.getElementById("username").value;
            const password = document.getElementById("password").value;
            const errorMsg = document.getElementById("errorMsg");

            // ✅ Dummy credentials for validation
            const validUsername = "admin";
            const validPassword = "123";

            if (username === validUsername && password === validPassword) {
                // ✅ Redirect to home page on successful login
                window.location.href = "/home";
            } else {
                errorMsg.style.display = "block";
                errorMsg.innerText = "❌ Invalid username or password!";
            }
        });
    }

    // ===========================
    // ✅ Home Page Animations
    // ===========================
    const cards = document.querySelectorAll(".card");
    cards.forEach((card, index) => {
        setTimeout(() => {
            card.style.opacity = "1";
            card.style.transform = "translateY(0)";
        }, index * 150);
    });

    // ===========================
    // ✅ File Upload Handling for Upload Page
    // ===========================
    const fileInput = document.getElementById("fileInput");
    const uploadBtn = document.getElementById("uploadBtn");
    const uploadMessage = document.getElementById("uploadMessage");

    if (fileInput && uploadBtn) {
        uploadBtn.addEventListener("click", () => {
            if (fileInput.files.length === 0) {
                uploadMessage.innerText = "⚠ Please select a file to upload.";
                uploadMessage.style.color = "red";
                return;
            }
            uploadFile(); // ✅ Call upload logic from api.js
        });
    }

    // ===========================
    // ✅ Fetch and Display Results for Results Page
    // ===========================
    if (document.getElementById("resultsTable")) {
        const urlParams = new URLSearchParams(window.location.search);
        const filename = urlParams.get('filename');

        if (!filename) return;

        fetch(`/get_result?filename=${filename}`)
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    document.getElementById('analysisContent').innerHTML = `<p class="text-danger">${data.error}</p>`;
                    return;
                }

                // Update basic file info
                document.getElementById('fileName').textContent = data.filename;
                document.getElementById('fileSize').textContent = `${data.size_kb} KB`;
                document.getElementById('uploadTime').textContent = data.upload_time;

                // Show errors in points
                const errorList = data.errors.length > 0
                    ? `<ul>${data.errors.map(err => `<li>${err}</li>`).join('')}</ul>`
                    : '<p class="text-success">✅ This file is clean and error-free!</p>';
                document.getElementById('errorDetails').innerHTML = errorList;

                // Table output
                const tableBody = document.getElementById('errorTableBody');
                tableBody.innerHTML = data.errors.map((err, i) =>
                    `<tr><td>${i + 1}</td><td>${err}</td></tr>`
                ).join('');

                // Pie & Bar Charts
                renderCharts(data.errors);
            })
            .catch(error => {
                console.error('Error fetching result:', error);
            });
    }
});

// ===========================
// ✅ Chart Drawing Logic
// ===========================
function renderCharts(errors) {
    const ctxPie = document.getElementById('errorPieChart').getContext('2d');
    const ctxBar = document.getElementById('errorBarChart').getContext('2d');

    const labels = errors.length ? errors.map((_, i) => `Error ${i + 1}`) : ["No Errors"];
    const dataCounts = errors.length ? new Array(errors.length).fill(1) : [1];
    const colors = ['#f44336', '#ff9800', '#2196f3', '#4caf50', '#9c27b0'];

    new Chart(ctxPie, {
        type: 'pie',
        data: {
            labels,
            datasets: [{
                data: dataCounts,
                backgroundColor: colors
            }]
        }
    });

    new Chart(ctxBar, {
        type: 'bar',
        data: {
            labels,
            datasets: [{
                label: 'Error Frequency',
                data: dataCounts,
                backgroundColor: colors
            }]
        }
    });
}
