from flask import Flask, request, jsonify
import os
import datetime
import sqlite3
import json

app = Flask(__name__)
UPLOAD_FOLDER = 'backend/uploads'
DATABASE = 'your_database_name.db'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def get_result_json(filename):
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute("SELECT result FROM files WHERE filename=?", (filename,))
    result_data = cursor.fetchone()
    conn.close()

    if result_data:
        try:
            return json.loads(result_data[0])
        except json.JSONDecodeError:
            return {"error": "Invalid result format"}
    else:
        return {"error": "No analysis found for this file"}

@app.route('/get_result')
def get_result():
    filename = request.args.get('filename')
    if not filename:
        return jsonify({"error": "No filename provided"}), 400

    file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)

    if not os.path.exists(file_path):
        return jsonify({"error": "File not found"}), 404

    file_size = os.path.getsize(file_path) / 1024  # KB
    upload_time = datetime.datetime.fromtimestamp(os.path.getmtime(file_path)).strftime('%Y-%m-%d %H:%M:%S')
    
    result_data = get_result_json(filename)

    if "error" in result_data:
        return jsonify(result_data), 404

    return jsonify({
        "filename": filename,
        "size_kb": round(file_size, 2),
        "upload_time": upload_time,
        "errors": result_data.get("errors", [])
    })

if __name__ == "__main__":
    app.run(debug=True)
