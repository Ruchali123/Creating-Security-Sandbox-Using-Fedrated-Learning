#!/bin/bash

# start.sh - Sandbox Initialization Script

echo "[INFO] Starting secure sandbox..."

# Restrict network access
echo "[INFO] Disabling network access..."
ip link set eth0 down 2>/dev/null || true

# Set execution directory
cd /sandbox || exit 1

# Wait for incoming execution request
echo "[INFO] Sandbox ready for execution."
exec tail -f /dev/null