import sqlite3
import json
from flask import Flask, request, jsonify, render_template, redirect, url_for
from flask_cors import CORS
import os
import joblib
import torch
import pandas as pd
from federated_training import create_clients, train_model, LogisticRegression

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
app = Flask(__name__, static_folder="static", template_folder=os.path.join(BASE_DIR, "templates"))

# Enable CORS
CORS(app, resources={r"/*": {"origins": "*"}})

# Database Setup
DATABASE = "app.db"
UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads")
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

# ===========================
# ✅ Initialize Database
# ===========================
def init_db():
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            password TEXT NOT NULL
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS files (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            filename TEXT NOT NULL,
            filepath TEXT NOT NULL,
            result TEXT,
            uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    conn.commit()
    conn.close()

init_db()

# ===========================
# ✅ Render HTML Pages
# ===========================
@app.route("/")
def index():
    return render_template("index.html")

@app.route("/home")
def home():
    return render_template("home.html")

@app.route("/upload")
def upload_page():
    return render_template("upload.html")

@app.route("/results.html")
def results_page():
    filename = request.args.get('filename', 'Unknown')
    size_kb = request.args.get('size_kb', 'Unknown')
    upload_time = request.args.get('upload_time', 'Unknown')
    return render_template("results.html", filename=filename, size_kb=size_kb, upload_time=upload_time)

# ===========================
# ✅ Handle 404 Errors
# ===========================
@app.errorhandler(404)
def page_not_found(e):
    return render_template("index.html"), 404

# ===========================
# ✅ File Upload Route
# ===========================
@app.route("/upload", methods=["POST"])
def upload_file():
    if "file" not in request.files:
        return jsonify({"error": "No file part"}), 400

    file = request.files["file"]
    if file.filename == "":
        return jsonify({"success": f"File {file.filename} uploaded successfully!"}), 200

    file_path = os.path.join(app.config["UPLOAD_FOLDER"], file.filename)
    file.save(file_path)

    # ✅ Store metadata
    try:
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        cursor.execute("INSERT INTO files (username, filename, filepath) VALUES (?, ?, ?)",
                       ("admin", file.filename, file_path))
        conn.commit()
    finally:
        conn.close()

    return redirect(url_for("analyze", filename=file.filename))

# ===========================
# ✅ Analyze File (Fixed name)
# ===========================
@app.route("/analyze/<filename>")
def analyze(filename):
    file_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
    if not os.path.exists(file_path):
        return jsonify({"error": "File not found"}), 404

    result = analyze_file(file_path)
    result_json = json.dumps(result)

    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute("UPDATE files SET result=? WHERE filename=?", (result_json, filename))
    cursor.execute("SELECT uploaded_at FROM files WHERE filename=?", (filename,))
    upload_info = cursor.fetchone()
    conn.commit()
    conn.close()

    file_size_kb = round(os.path.getsize(file_path) / 1024, 2)
    upload_time = upload_info[0] if upload_info else "Unknown"

    return render_template("results.html",
                           filename=filename,
                           size_kb=file_size_kb,
                           upload_time=upload_time,
                           result=result)

# ===========================
# ✅ Analysis Logic (Dynamic)
# ===========================
def analyze_file(file_path):
    try:
        df = pd.read_csv(file_path)

        avg_proc = df["pslist.nproc"].mean()
        avg_dlls = df["dlllist.ndlls"].mean()

        if avg_proc > 70:
            anomaly = "High number of processes detected"
        else:
            anomaly = "No anomaly found"

        if avg_dlls > 100:
            pattern = "Suspicious DLL usage"
        else:
            pattern = "Login pattern matched"

        network = "Traffic normal"

        return {
            "anomaly_detection": anomaly,
            "pattern_recognition": pattern,
            "network_traffic": network
        }

    except Exception as e:
        return {
            "anomaly_detection": "Error analyzing file",
            "pattern_recognition": "Error analyzing file",
            "network_traffic": str(e)
        }

# ===========================
# ✅ Parse Result from DB
# ===========================
def parse_result(filename):
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute("SELECT result FROM files WHERE filename=?", (filename,))
    result_data = cursor.fetchone()
    conn.close()

    if not result_data or not result_data[0]:
        return {
            "anomaly_detection": "N/A",
            "pattern_recognition": "N/A",
            "network_traffic": "N/A"
        }

    try:
        parsed = json.loads(result_data[0])
        return {
            "anomaly_detection": parsed.get("anomaly_detection", "N/A"),
            "pattern_recognition": parsed.get("pattern_recognition", "N/A"),
            "network_traffic": parsed.get("network_traffic", "N/A")
        }
    except json.JSONDecodeError:
        return {
            "anomaly_detection": "Error parsing result",
            "pattern_recognition": "Error parsing result",
            "network_traffic": result_data[0]
        }

# ===========================
# ✅ Federated Training
# ===========================
def run_federated_training():
    data = joblib.load("uploads/federated_data.pkl")
    clients = create_clients(data['network_traffic']['X_train'], data['network_traffic']['y_train'])
    model = LogisticRegression(input_dim=data['network_traffic']['X_train'].shape[1])
    train_model(clients, model)
    torch.save(model.state_dict(), "backend/global_model.pth")

# ===========================
# ✅ API: Get Result by Filename
# ===========================
@app.route('/get_result')
def get_result():
    filename = request.args.get('filename')
    if not filename:
        return jsonify({'error': 'Filename is required'}), 400

    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute("SELECT result FROM files WHERE filename = ?", (filename,))
    row = cursor.fetchone()
    conn.close()

    if row:
        result = json.loads(row[0])
        return jsonify(result)
    else:
        return jsonify({'error': 'Result not found'}), 404

# ===========================
# ✅ Training Log Display
# ===========================
@app.route("/training-log")
def show_training_log():
    log_file_path = os.path.join(app.config["UPLOAD_FOLDER"], "results_log.txt")
    if os.path.exists(log_file_path):
        with open(log_file_path, "r") as f:
            log_content = f.read()
    else:
        log_content = "No log file found."

    return render_template("results.html", log_output=log_content)

# ===========================
# ✅ Run Flask App
# ===========================
if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5001, debug=True)
