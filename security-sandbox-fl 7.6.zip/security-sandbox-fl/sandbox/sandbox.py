import os
import subprocess
import sys

def execute_file(file_path):
    if not os.path.exists(file_path):
        print("[Error] File not found.")
        return
    
    try:
        print(f"[INFO] Executing file: {file_path}")
        result = subprocess.run(["/bin/bash", file_path], capture_output=True, text=True, timeout=10)
        print("[OUTPUT]:", result.stdout.strip())
        if result.stderr.strip(): #only print if stderr is not empty
            print("[ERROR]:", result.stderr.strip())
            
    except subprocess.TimeoutExpired:
        print("[ERROR] Execution timed out.")
    except Exception as e:
        print(f"[ERROR] Execution failed: {e}")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 sandbox.py <file_to_execute>")
    else:
        execute_file(sys.argv[1])