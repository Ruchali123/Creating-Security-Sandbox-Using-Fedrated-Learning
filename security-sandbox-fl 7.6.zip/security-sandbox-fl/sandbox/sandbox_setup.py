import os
import subprocess

# Define Docker setup commands
def setup_sandbox():
    print("🚀 Setting up sandbox environment...")
    os.system("docker build -t sandbox -f Dockerfile .")
    os.system("docker run -d --name sandbox_container sandbox")

if __name__ == "__main__":
    setup_sandbox()
