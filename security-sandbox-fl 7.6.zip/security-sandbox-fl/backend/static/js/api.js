// =========================
// ✅ Correct Backend URL
// =========================
const BACKEND_URL = "http://127.0.0.1:5001";  // Flask running locally
const FRONTEND_URL = "http://127.0.0.1:5500";  // Frontend URL if using local live server

// =========================
// ✅ Upload and Redirect Logic
// =========================
async function uploadFile() {
    const fileInput = document.getElementById("fileInput");
    const uploadMessage = document.getElementById("uploadMessage");

    if (!fileInput.files.length) {
        uploadMessage.innerText = "⚠ No file selected!";
        uploadMessage.style.color = "red";
        return;
    }

    const file = fileInput.files[0];
    const formData = new FormData();
    formData.append("file", file);

    try {
        uploadMessage.innerText = "⏳ Uploading...";
        uploadMessage.style.color = "blue";

        // ✅ Correct URL using template literal
        const response = await fetch(`${BACKEND_URL}/upload`, {
            method: "POST",
            body: formData,
        });
        
        // ✅ Check if Flask sends a redirect after successful upload
        if (response.redirected) {
            window.location.href = response.url; // ✅ Redirect to frontend URL
        } else {
            const result = await response.json();
            if (response.ok) {
                uploadMessage.innerText = `✅ ${result.message}`;
                uploadMessage.style.color = "green";
                loadResults(); // Reload results after upload
            } else {
                uploadMessage.innerText = `❌ ${result.error}`;
                uploadMessage.style.color = "red";
            }
        }
    } catch (error) {
        console.error("Error during file upload:", error);
        uploadMessage.innerText = "❌ Network error. Please check the backend.";
        uploadMessage.style.color = "red";
    }
}

// =========================
// ✅ Load Results Data
// =========================
async function loadResults() {
    const resultsTable = document.getElementById("resultsTable");
    const loadingMessage = document.getElementById("loadingMessage");

    try {
        // Show loading while fetching results
        loadingMessage.innerText = "⏳ Loading results...";
        const response = await fetch(`${BACKEND_URL}/upload`, {
            method: "POST",
            body: formData,
        });
        

        if (!response.ok) {
            throw new Error("Failed to fetch results.");
        }

        const data = await response.json();
        resultsTable.innerHTML = ""; // Clear previous results
        loadingMessage.innerText = "";

        if (data.length === 0) {
            resultsTable.innerHTML =
                "<tr><td colspan='2' class='text-center'>No results found.</td></tr>";
            return;
        }

        // ✅ Populate the results table with fetched data
        data.forEach((file) => {
            const row = `<tr><td>${file[0]}</td><td>${file[1]}</td></tr>`;
            resultsTable.innerHTML += row;
        });
    } catch (error) {
        console.error("Error loading results:", error);
        loadingMessage.innerText = "❌ Failed to load results.";
    }
}

// =========================
// ✅ Reload Results on Button Click
// =========================
const reloadBtn = document.getElementById("reloadBtn");
if (reloadBtn) {
    reloadBtn.addEventListener("click", loadResults);
}

// =========================
// ✅ Automatically Load Results on Page Load
// =========================
document.addEventListener("DOMContentLoaded", () => {
    if (document.getElementById("resultsTable")) {
        loadResults(); // Load results automatically
    }
});
